# Plan-B Static Frontend
- Frontend: GitHub Pages (this folder)
- Backend API: https://api.stockpricepredictions.com (Render)

Files:
- index.html, style.css, script.js
- about.html, privacy.html, contact.html
- 404.html (redirects unknown paths to home)
